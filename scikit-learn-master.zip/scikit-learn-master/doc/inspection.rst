.. include:: includes/big_toc_css.rst

.. _inspection:

Inspection
----------

.. toctree::

    modules/partial_dependence
