#!/bin/bash

set -e
set -x

make test-doc
